import React from 'react'

function Logout() {
  return (
    <div>
      
    </div>
  )
}

export default Logout
