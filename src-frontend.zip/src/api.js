// export const baseUrl = "https://todo-backend-mcjo.onrender.com";
export const baseUrl = import.meta.env.VITE_API_URL;
console.log("BASE URL ===>", baseUrl);



